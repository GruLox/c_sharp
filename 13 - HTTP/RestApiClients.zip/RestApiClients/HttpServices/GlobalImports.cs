﻿global using System.IO.Compression;
global using System.Net.Http.Headers;
global using System.Net.Mime;
global using System.Text;
global using System.Text.Json;
global using System.Text.Json.Serialization;
global using HttpServices;
global using Models;
global using System.Web;


